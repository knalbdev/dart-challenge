int calculate() {
  return 6 * 7;
}
